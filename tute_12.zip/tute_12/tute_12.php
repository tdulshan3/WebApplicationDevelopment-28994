
    <html>
    <head> </head>
    <body style="padding: 200px">
    <?php
        $f = $_REQUEST['fn'];
        $l = $_REQUEST['ln'];
        $u = $_REQUEST['un'];
        $p = $_REQUEST['pw'];
        $g = $_REQUEST['g'];
        $y = $_REQUEST['yr'];
        $no = $_REQUEST['no'];
    ?>
                <table align="center" border="1">
                    <tr>
                        <td >First Name</td>
                        <td><?php echo "$f"?> </td>
                    </tr>
                    <tr>
                        <td >Last Name</td>
                        <td><?php echo "$l"?> </td>
                    </tr>
                    <tr>
                        <td >User Name</td>
                        <td><?php echo "$u"?> </td>
                    </tr>
                    <tr>
                        <td >Password</td>
                        <td><?php echo "$f"?> </td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td><?php if ($g=="m") {
                            echo "Male";
                        }
                        else {
                            echo "Female";
                        } 
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td >Academic year</td>
                        <td><?php echo "$y"?> </td>
                    </tr>
                    <tr>
                        <td >Mobile Number</td>
                        <td><?php echo "$no"?> </td>
                    </tr>
                </table>
            </form>
                
    </body>
</html>

